import os
import joblib
import numpy as np
import pandas as pd
import shap
import lime
import lime.lime_tabular
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from django.shortcuts import render, redirect
from django.conf import settings
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required


# =====================================================
# 1️⃣ MODEL & DATA LOADING
# =====================================================

MODEL_PATH = os.path.join(settings.BASE_DIR, 'core', 'static', 'saved_model.pkl')
DATA_PATH = os.path.join(settings.BASE_DIR, 'core', 'static', 'processed.csv')

model = None
X_train = None

try:
    model = joblib.load(MODEL_PATH)
    print("✅ Model Loaded Successfully")
except Exception as e:
    print("❌ Model Loading Error:", e)

try:
    df = pd.read_csv(DATA_PATH)
    X_train = df.drop("TEST", axis=1)
    print("✅ Training Data Loaded")
except Exception as e:
    print("❌ Training Data Error:", e)


# =====================================================
# 2️⃣ AUTHENTICATION
# =====================================================

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            login(request, form.get_user())
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login')


def home_view(request):
    return render(request, 'home.html')


# =====================================================
# 3️⃣ PREDICTION + SHAP + LIME
# =====================================================

@login_required
def predict(request):

    result = None
    shap_image = None
    lime_image = None
    confidence = None

    if request.method == 'POST':

        try:
            # -----------------------------
            # Collect Input
            # -----------------------------
            input_features = [
                float(request.POST.get('age')),
                float(request.POST.get('sex')),
                float(request.POST.get('rbc')),
                float(request.POST.get('pcv')),
                float(request.POST.get('mcv')),
                float(request.POST.get('mch')),
                float(request.POST.get('mchc')),
                float(request.POST.get('rdw')),
                float(request.POST.get('tlc')),
                float(request.POST.get('plt')),
                float(request.POST.get('hgb'))
            ]

            input_array = np.array([input_features])

            # -----------------------------
            # Prediction
            # -----------------------------
            prediction = model.predict(input_array)[0]
            proba = model.predict_proba(input_array)[0]
            confidence = round(max(proba) * 100, 2)

            if prediction == 1:
                result = "Positive (Disease Detected)"
            else:
                result = "Negative (Healthy)"

            # =====================================================
            # 🔥 SHAP (FINAL STABLE VERSION - v0.20+)
            # =====================================================
            # =====================================================
            # 🔥 SHAP FINAL FIX (FOR BINARY CLASSIFICATION)
            # =====================================================

            explainer = shap.TreeExplainer(model)

            shap_values = explainer(input_array)

            # Select class 1 (Disease)
            shap_value_single = shap_values[0][:, 1]

            # Create Explanation object manually
            single_explanation = shap.Explanation(
            values=shap_value_single,
            base_values=explainer.expected_value[1],
            data=input_array[0],
            feature_names=X_train.columns
            )

            plt.figure()
            shap.plots.waterfall(single_explanation, show=False)

            os.makedirs(settings.MEDIA_ROOT, exist_ok=True)

            shap_path = os.path.join(settings.MEDIA_ROOT, 'shap_plot.png')
            plt.savefig(shap_path, bbox_inches='tight')
            plt.close()

            shap_image = settings.MEDIA_URL + 'shap_plot.png'

            # =====================================================
            # 🔥 LIME
            # =====================================================

            lime_explainer = lime.lime_tabular.LimeTabularExplainer(
                training_data=X_train.values,
                feature_names=X_train.columns.tolist(),
                class_names=['Healthy', 'Disease'],
                mode='classification'
            )

            exp = lime_explainer.explain_instance(
                input_array[0],
                model.predict_proba,
                num_features=5
            )

            lime_path = os.path.join(settings.MEDIA_ROOT, 'lime_plot.html')
            exp.save_to_file(lime_path)

            lime_image = settings.MEDIA_URL + 'lime_plot.html'

        except Exception as e:
            result = f"Error: {str(e)}"

    return render(request, 'prediction.html', {
        'result': result,
        'confidence': confidence,
        'shap_image': shap_image,
        'lime_image': lime_image
    })


# =====================================================
# 4️⃣ DASHBOARD
# =====================================================

@login_required
def dashboard(request):
    return render(request, 'dashboard.html')