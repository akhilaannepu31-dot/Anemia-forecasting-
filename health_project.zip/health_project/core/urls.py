from django.urls import path
from core import views

urlpatterns = [
    path('', views.home_view, name='home'),          # Changed to home_view
    path('signup/', views.signup_view, name='signup'), # Changed to signup_view
    path('login/', views.login_view, name='login'),    # Changed to login_view
    path('logout/', views.logout_view, name='logout'),
    path('predict/', views.predict, name='predict'),
    path('dashboard/', views.dashboard, name='dashboard'),
]