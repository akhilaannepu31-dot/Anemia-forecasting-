import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# 1. Setup Directories
# We save into 'core/static' so Django can find them easily
static_dir = os.path.join('core', 'static')
os.makedirs(static_dir, exist_ok=True)

# 2. Load and Prepare Data
df = pd.read_csv('processed.csv')
df = df.dropna()

X = df.drop('TEST', axis=1)
y = df['TEST']

# Split Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 3. Define 5 Algorithms
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "SVM": SVC(),
    "Decision Tree": DecisionTreeClassifier(),
    "Random Forest": RandomForestClassifier(),
    "KNN": KNeighborsClassifier()
}

# 4. Train and Evaluate
results = {}
best_model = None
best_acc = 0
best_model_name = ""

print("Training models...")
for name, model in models.items():
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    results[name] = acc
    
    print(f"{name}: {acc:.4f}")
    
    # Track best model
    if acc > best_acc:
        best_acc = acc
        best_model = model
        best_model_name = name

print(f"\nBest Model: {best_model_name} with {best_acc:.4f} accuracy")

# 5. Generate and Save Comparison Graph
plt.figure(figsize=(10, 6))
sns.barplot(x=list(results.keys()), y=list(results.values()), palette='viridis')
plt.title(f'Model Accuracy Comparison (Best: {best_model_name})')
plt.ylabel('Accuracy')
plt.ylim(0, 1.1)
plt.xticks(rotation=15)
plt.tight_layout()

graph_path = os.path.join(static_dir, 'comparison.png')
plt.savefig(graph_path)
print(f"Graph saved to: {graph_path}")

# 6. Save the Best Model
model_path = os.path.join(static_dir, 'saved_model.pkl')
joblib.dump(best_model, model_path)
print(f"Model saved to: {model_path}")